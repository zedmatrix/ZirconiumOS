#!/bin/bash
set +h
umask 022

ZBefore=`date +%s`
zzreset="\033[0m"
zzwhite="\033[1;37m"
zzred="\033[1;31m"
zzpurple="\033[1;35m"
zoption=$1
SET_PASSWORD=0
LC_ALL=POSIX

zprint() { echo -e "${zzwhite} *** $* *** ${zzreset}"; }
zmsg() { echo -e "${zzred} *** $* *** ${zzreset}"; }
stars() { echo -e "${zzpurple} $(printf '%.0s*' {1..100}) ${zzreset}"; }

print_formatted_duration() {
    duration=$1
    hour=$((duration / 3600))
    mins=$(( (duration % 3600) / 60 ))
    sec=$((duration % 60))
    zprint $(printf "%02d Hours, %02d Minutes and %02d Seconds \n" ${hour} ${mins} ${sec})
}

zbuild_check() {
    local file="$1"
    if [[ -f ${ZBUILD}/${file} ]]; then
        return 0
    else
        stars
        zprint "Error: Missing $file ... Exiting"
        return 1
    fi
}

zbuild_wait() {
    local wait=${1:-5}
    zmsg "Waiting $wait seconds or Press [SPACE] to continue..."
    read -t $wait -n 1 key
    if [[ $key == " " ]]; then
        zmsg "Skipped wait."
    else
        zmsg "Continuing..."
    fi
}
zbuild_exec() {
    local file="$1"
    case "$file" in
        *.zbc)
            ${ZBUILD}/zbuild "${ZBUILD}/$file" || { echo "Error: $file - Exiting: $?"; return 1; }
            ;;
        *.sh)
            "${ZBUILD}/$file" || { echo "Error: $file - Exiting: $?"; return 1; }
            ;;
        *)
            zmsg "Invalid File Found in Stream"
            return 666
            ;;
    esac
}
check_chroot() {
    IS_CHROOT=0
    if [[ ! /proc/1/root/. -ef / ]]; then
        zmsg "Inside chroot"
        ZBUILD=${ZBUILD:-/zbuild}
        ZSRC=${ZSRC:-/sources}
        IS_CHROOT=1
    else
        zmsg "Outside chroot"
        source $(pwd)/stage0/0-environment.sh || { zmsg "Error Getting Environment"; exit 1; }
    fi
}

check_chroot
STAGE=0
case "$zoption" in
    "1")
        zprint "Stage 1 Section 1 Build"
        [[ $IS_CHROOT -eq 0 ]] && {
            STAGE=1
            stage_build=$(printf "%s " stage1/{100..121}-*.zbc)
        }
        ;;
    "2")
        zprint "Stage 1 Section 2 Build"
        [[ $IS_CHROOT -eq 1 ]] && {
            STAGE=2
            stage_build=$(printf "%s " stage1/{200..208}-*)
        }
        ;;
    "3")
        zprint "Stage 3 Base System"
        [[ $IS_CHROOT -eq 1 ]] && {
            ZBUILD_PASSWORD="${2:-lfsroot}"
            SET_PASSWORD=1
            STAGE=3
            echo "root:${ZBUILD_PASSWORD}"
            stage_build=$(printf "%s " stage2/{001..079}-*.zbc)
        }
        ;;
    "4")
        zprint "Stage 4 Configuration"
        [[ $IS_CHROOT -eq 1 ]] && {
            STAGE=4
            stage_build=$(printf "%s " stage2/{100..107}-*.sh)
        }
        ;;
    "5")
        zprint "Stage 5 Extra Packages"
        [[ $IS_CHROOT -eq 1 ]] && {
            STAGE=5
            stage_build=$(printf "%s " stage2/{110..129}-*.zbc)
        }
        ;;
    "6")
        zprint "Stage 6 Finalize and Reboot"
        [[ $IS_CHROOT -eq 1 ]] && {
            STAGE=6
            stage_build=$(printf "%s " stage2/{200..202}-*.sh)
        }
        ;;
    *)
        zprint "Usage: $0 1 - Primary Build Not in Chroot"
        zprint " The Following Options Require chroot "
        zprint " $0 2 - Extra Temporary Packages"
        zprint " $0 3 {password} - Main Build System"
        zprint " $0 4 - Finalize Scripts"
        zprint " $0 5 - Extra Packages"
        zprint " $0 6 - Kernel and Grub Setup"
esac

ZERROR=0
for script in ${stage_build[@]}; do
    stars
    zprint "Executing ${script}"
    zbuild_check "${script}" || break
    zbuild_wait 5
    zbuild_exec "${script}" || ZERROR=666
    stars
done
if [[ $ZERROR -eq 0 ]]; then
    if [[ $STAGE -eq 2 ]]; then
        zmsg "Cleaning up Temporary Tools"
        rm -rf /usr/share/{info,man,doc}/*
        find /usr/{lib,libexec} -name \*.la -delete
        rm -rf /tools
        rm -rf /zbuild/log/*
        rm -rf /zbuild/tmp/*
    fi

    if [[ $SET_PASSWORD -eq 1 ]]; then
        echo "${ZBUILD_PASSWORD}" | passwd --stdin root
    fi

    if [[ $STAGE -eq 3 ]]; then
        zmsg "Cleaning Up Temporary Files"
        rm -rf /tmp/{*,.*}
        find /usr/lib /usr/libexec -name \*.la -delete
        find /usr -depth -name $(uname -m)-lfs-linux-gnu\* | xargs rm -rf
    fi
fi

ZAfter=`date +%s`
let duration=ZAfter-ZBefore
print_formatted_duration $duration
