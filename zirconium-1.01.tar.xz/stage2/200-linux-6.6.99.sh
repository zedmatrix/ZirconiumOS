#!/bin/bash
zmsg() { printf "*** %s ***\n" "${@}"; }

pkgdir="linux-6.6.99"
pkgname="linux"
pkgver="6.6.99"
pkgurl="https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-6.6.99.tar.xz"
md5sum="f7954f42a111d7ae912536afd20963e8"

ZBUILD=${ZBUILD:-/zbuild}
ZSRC=${ZSRC:-/sources}

# extract
archive=$(basename $pkgurl)

if [[ ! -f "${ZSRC}/${archive}" ]]; then
    zmsg "Downloading: ${archive} "
    [ ! -x "/usr/bin/wget" ] && { zmsg "You Should Have Installed Wget. Missing. Exiting."; exit 1; }
    wget -P ${ZSRC} ${pkgurl}
fi

zmsg "Extracting: ${pkgdir}"
pushd /usr/src || exit 1

tar xf ${ZSRC}/${archive} || exit 1

ln -sv /usr/src/${pkgdir} linux

zmsg "Preparing: ${pkgdir}"
cd linux

make mrproper

cp -v ${ZBUILD}/stage2/zbase-config-6.6.94 .config || exit 1
make olddefconfig

zmsg "Building: ${pkgdir}"
make || exit 1
make modules_install

zmsg "Installing: ${pkgdir}"
cp -iv arch/x86/boot/bzImage /boot/vmlinuz-${pkgver}-zirconium
cp -iv System.map /boot/System.map-${pkgver}
cp -iv .config /boot/config-${pkgver}

popd
