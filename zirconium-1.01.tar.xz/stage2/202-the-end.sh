#!/bin/bash
zzreset="\033[0m"
zzwhite="\033[1;37m"
zmsg() { echo -e "${zzwhite} *** $* *** ${zzreset}"; }

zmsg "Finalizing and Reboot"

zmsg "Installing OpenSSH systemd service file"
pushd /opt
tar xf /sources/blfs-systemd-units-20241211.tar.xz
cd blfs-systemd-units-20241211/
make install-sshd
popd

zmsg "Setting Up to allow root login til all other packages are built"
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config &&
echo "PasswordAuthentication yes" >> /etc/ssh/sshd_config &&
echo "KbdInteractiveAuthentication yes" >> /etc/ssh/sshd_config

zmsg "The End - Distro Notes"
echo "Zirconium r12.3-77-systemd" > /etc/lfs-release

cat > /etc/lsb-release << "EOF"
DISTRIB_ID="Zirconium"
DISTRIB_RELEASE="r12.3-77-systemd"
DISTRIB_CODENAME="Zirconium"
DISTRIB_DESCRIPTION="Linux From Scratch"
EOF

cat > /etc/os-release << "EOF"
NAME="Zirconium"
VERSION="r12.3-77-systemd"
ID=lfs
PRETTY_NAME="Zirconium r12.3-77-systemd"
VERSION_CODENAME="Zirconium"
HOME_URL="https://www.linuxfromscratch.org/lfs/"
RELEASE_TYPE="development"
EOF

zmsg "Done"
