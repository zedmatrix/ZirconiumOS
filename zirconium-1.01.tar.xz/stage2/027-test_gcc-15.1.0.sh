#!/bin/bash

echo " *** Testing GCC-15.1.0 *** "

TESTDIR="$(pwd)/gcc-15.1.0-test"
mkdir -v $TESTDIR
pushd $TESTDIR

echo 'int main(){}' | cc -x c - -v -Wl,--verbose &> dummy.log
readelf -l a.out | grep ': /lib'

grep -E -o '/usr/lib.*/S?crt[1in].*succeeded' dummy.log

grep -B4 '^ /usr/include' dummy.log

grep 'SEARCH.*/usr/lib' dummy.log |sed 's|; |\n|g'

grep "/lib.*/libc.so.6 " dummy.log

grep found dummy.log

popd
rm -rf $TESTDIR && echo "Cleaned Up: $TESTDIR"

echo " *** DONE *** "
