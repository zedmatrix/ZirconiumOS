#!/bin/bash
echo "*** Preparing and Running Tests ***"
LFS=${LFS:-/mnt/lfs}
LFS_TGT=${LFS_TGT:-$(uname -m)-lfs-linux-gnu}

TESTDIR="$(pwd)/103-glibc-tests"
mkdir -v $TESTDIR && pushd $TESTDIR

echo 'int main(){}' | $LFS_TGT-gcc -x c - -v -Wl,--verbose &> dummy.log

readelf -l a.out | grep ': /lib'

grep -E -o "$LFS/lib.*/S?crt[1in].*succeeded" dummy.log

grep -B3 "^ $LFS/usr/include" dummy.log

grep 'SEARCH.*/usr/lib' dummy.log |sed 's|; |\n|g'

grep "/lib.*/libc.so.6 " dummy.log

grep found dummy.log

popd

rm -rf $TESTDIR && echo "Removed Temporary Test Directory"
echo "*** Finished ***"
